param(
    [Parameter(Mandatory=$true)] [string] $ResourceGroupName,
    [Parameter(Mandatory=$true)] [string] $VmName,
    [Parameter(Mandatory=$true)] [string] $TicketNumber
)

Write-Host "Change ticket: $TicketNumber"
Write-Host "Preparing to restart VM: $VmName in resource group: $ResourceGroupName"

$confirmation = Read-Host "Type YES to confirm restart"
if ($confirmation -ne "YES") {
    Write-Host "Restart cancelled."
    exit
}

az vm restart --resource-group $ResourceGroupName --name $VmName
Write-Host "Restart command submitted. Validate application and monitoring after restart."
