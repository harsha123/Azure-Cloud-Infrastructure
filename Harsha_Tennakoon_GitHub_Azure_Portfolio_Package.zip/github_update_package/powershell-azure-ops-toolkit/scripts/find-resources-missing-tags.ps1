param(
    [string[]] $RequiredTags = @("owner", "environment", "costCenter")
)

Write-Host "Checking Azure resources missing required tags..."

$resources = az resource list -o json | ConvertFrom-Json
$result = foreach ($resource in $resources) {
    foreach ($tag in $RequiredTags) {
        if (-not $resource.tags -or -not $resource.tags.$tag) {
            [PSCustomObject]@{
                Name = $resource.name
                Type = $resource.type
                ResourceGroup = $resource.resourceGroup
                MissingTag = $tag
            }
        }
    }
}

$result | Format-Table -AutoSize
