param(
    [string] $ResourceGroupName
)

Write-Host "Checking diagnostic settings for resources..."

if ($ResourceGroupName) {
    $resources = az resource list --resource-group $ResourceGroupName -o json | ConvertFrom-Json
} else {
    $resources = az resource list -o json | ConvertFrom-Json
}

foreach ($resource in $resources) {
    Write-Host "Resource: $($resource.name)"
    az monitor diagnostic-settings list --resource $resource.id --query "[].name" -o table
}

Write-Host "Manual review required: some resource types may not support diagnostics or may use different logging configuration."
