param(
    [string] $OutputPath = "azure-vm-health.csv"
)

Write-Host "Collecting Azure VM health summary..."

$vms = az vm list -d --query "[].{Name:name, ResourceGroup:resourceGroup, Location:location, PowerState:powerState, Size:hardwareProfile.vmSize, PrivateIP:privateIps, PublicIP:publicIps}" -o json | ConvertFrom-Json
$vms | Export-Csv -Path $OutputPath -NoTypeInformation

Write-Host "Report created: $OutputPath"
