# Script Usage Guide

## Prerequisites

- Azure CLI installed
- PowerShell 7 recommended
- User logged in using `az login`
- Correct subscription selected using `az account set --subscription <subscription-id>`

## Good operational practice

- Run scripts first in test/dev subscription
- Use change tickets for production actions
- Export results and attach them to ITSM tickets where useful
- Never hardcode secrets or production identifiers
- Review script output before taking corrective action
