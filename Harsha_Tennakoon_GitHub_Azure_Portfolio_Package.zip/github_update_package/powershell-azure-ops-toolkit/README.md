# PowerShell Azure Operations Toolkit

Reusable PowerShell and Azure CLI scripts for Azure infrastructure support and L2/L3 operations.

## Scripts

| Script | Purpose |
|---|---|
| `get-azure-vm-health.ps1` | Export VM power state, size, IPs and location |
| `find-resources-missing-tags.ps1` | Find Azure resources without required operational tags |
| `check-diagnostic-settings.ps1` | Check resources that may be missing diagnostic settings |
| `restart-vm-with-ticket.ps1` | Example controlled VM restart with ticket reference |

## Skills Highlighted

PowerShell, Azure CLI, Azure inventory, governance checks, diagnostics validation, change control and operational reporting.

## Safety

These scripts use placeholders and should be tested in a non-production subscription before real use.
