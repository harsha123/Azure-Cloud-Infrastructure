# Change Implementation Checklist

## Before change

- Confirm change approval and change window
- Confirm rollback plan
- Confirm affected services and owners
- Review backup/snapshot status if required
- Validate access permissions
- Notify stakeholders

## During change

- Record start time
- Follow implementation steps exactly
- Validate each major step
- Capture screenshots/logs if needed
- Stop and escalate if unexpected behavior appears

## After change

- Run functional validation
- Confirm monitoring is green
- Confirm no new alerts or errors
- Update ITSM ticket with evidence
- Notify stakeholders
- Record lessons learned
