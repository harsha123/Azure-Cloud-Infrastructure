# Azure Infrastructure Incident Triage Runbook

## 1. Confirm the impact

- What service is affected?
- How many users or systems are affected?
- Is this production or non-production?
- When did the issue start?
- Was there a recent change?

## 2. Check Azure service health

- Azure Service Health
- Resource Health
- Subscription alerts
- Region-specific incidents

## 3. Check resource-level signals

- VM status and boot diagnostics
- CPU, memory, disk and network metrics
- NSG flow logs if enabled
- Activity Log for changes
- Log Analytics query results

## 4. Network checks

- DNS resolution
- NSG rules
- Route table / UDR
- Firewall or VPN status
- Private endpoint DNS zone links

## 5. Restore service

- Apply known workaround if approved
- Roll back recent change if needed
- Escalate to network/security/application owner if outside cloud scope
- Document actions in ITSM ticket

## 6. Post-incident follow-up

- Root cause analysis
- Corrective action
- Monitoring improvement
- Runbook update
- Problem record if recurring
