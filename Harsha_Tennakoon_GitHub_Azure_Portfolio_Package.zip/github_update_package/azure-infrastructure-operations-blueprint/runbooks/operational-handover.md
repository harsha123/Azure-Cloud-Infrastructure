# Operational Handover Template

## Service summary

- Service name:
- Owner:
- Support group:
- Environment:
- Business criticality:

## Architecture summary

- Resource groups:
- VNets/subnets:
- Key compute resources:
- Storage accounts:
- Backup vault:
- Monitoring workspace:

## Access model

- Admin groups:
- Reader groups:
- Break-glass process:
- MFA/Conditional Access notes:

## Monitoring

- Alerts configured:
- Log Analytics workspace:
- Dashboards/workbooks:
- Escalation path:

## Backup and recovery

- Backup policy:
- Retention:
- Restore test date:
- RTO/RPO target:

## Known risks

- Open risks:
- Technical debt:
- Pending tasks:
