@description('Azure region')
param location string = resourceGroup().location

@description('Environment name, for example dev, test or prod')
param environment string = 'dev'

@description('Project or workload name')
param workloadName string = 'infraops'

@description('Address prefix for the workload VNet')
param vnetAddressPrefix string = '10.20.0.0/16'

@description('Common tags for ownership, cost and operations')
param tags object = {
  owner: 'cloud-operations'
  environment: 'dev'
  costCenter: 'shared-services'
  managedBy: 'bicep'
}

var namePrefix = '${workloadName}-${environment}'

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: '${namePrefix}-law'
  location: location
  tags: tags
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
}

resource vnet 'Microsoft.Network/virtualNetworks@2023-11-01' = {
  name: '${namePrefix}-vnet'
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        vnetAddressPrefix
      ]
    }
    subnets: [
      {
        name: 'snet-management'
        properties: {
          addressPrefix: '10.20.1.0/24'
        }
      }
      {
        name: 'snet-application'
        properties: {
          addressPrefix: '10.20.2.0/24'
        }
      }
      {
        name: 'snet-data'
        properties: {
          addressPrefix: '10.20.3.0/24'
        }
      }
      {
        name: 'snet-private-endpoints'
        properties: {
          addressPrefix: '10.20.4.0/24'
          privateEndpointNetworkPolicies: 'Disabled'
        }
      }
    ]
  }
}

resource nsgMgmt 'Microsoft.Network/networkSecurityGroups@2023-11-01' = {
  name: '${namePrefix}-mgmt-nsg'
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'Deny-Internet-Inbound'
        properties: {
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'Internet'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

resource recoveryVault 'Microsoft.RecoveryServices/vaults@2023-04-01' = {
  name: '${namePrefix}-rsv'
  location: location
  tags: tags
  sku: {
    name: 'RS0'
    tier: 'Standard'
  }
  properties: {}
}

output logAnalyticsWorkspaceName string = logAnalytics.name
output vnetName string = vnet.name
output recoveryVaultName string = recoveryVault.name
