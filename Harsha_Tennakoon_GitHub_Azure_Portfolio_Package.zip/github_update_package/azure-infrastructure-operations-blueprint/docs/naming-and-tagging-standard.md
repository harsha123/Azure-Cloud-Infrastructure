# Naming and Tagging Standard

## Naming pattern

Recommended pattern:

```text
<workload>-<environment>-<resource-type>-<region>-<number>
```

Example:

```text
infraops-dev-vnet-sdc-001
infraops-dev-law-sdc-001
infraops-dev-rsv-sdc-001
```

## Required tags

| Tag | Example | Purpose |
|---|---|---|
| owner | cloud-operations | Operational owner |
| environment | dev/test/prod | Lifecycle and access control |
| costCenter | shared-services | Cost tracking |
| managedBy | bicep/manual | Support and lifecycle clarity |
| criticality | low/medium/high | Incident priority and DR planning |

## Operational benefit

Good naming and tagging helps with cost reporting, ownership, troubleshooting, incident routing and audit readiness.
