# Azure Security Baseline

## Identity and access

- Use least privilege access through Azure RBAC
- Use Microsoft Entra ID groups for role assignments
- Require MFA for privileged users
- Use PIM for just-in-time privileged access where available
- Avoid direct user assignments where possible

## Network security

- Segment workloads by subnet
- Use NSGs for subnet-level traffic control
- Avoid direct public exposure of management ports
- Prefer Bastion, VPN or private access for administration
- Document firewall rules and business justification

## Monitoring and logging

- Enable diagnostic settings for important resources
- Send logs to Log Analytics
- Review Activity Log for administrative changes
- Configure alerts for service-critical signals

## Backup and resilience

- Enable Azure Backup for critical VMs
- Define RTO/RPO expectations
- Test restore process regularly
- Document failover/failback steps

## Cost and governance

- Apply required tags
- Review idle resources
- Use policy to enforce baseline controls
- Review recommendations in Defender for Cloud
