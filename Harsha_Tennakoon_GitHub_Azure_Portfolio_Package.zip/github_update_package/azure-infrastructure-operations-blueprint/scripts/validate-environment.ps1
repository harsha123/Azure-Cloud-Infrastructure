param(
    [Parameter(Mandatory=$true)] [string] $ResourceGroupName
)

Write-Host "Validating Azure infrastructure baseline for resource group: $ResourceGroupName"

$resources = az resource list --resource-group $ResourceGroupName --query "[].{Name:name, Type:type, Location:location}" -o table
$resources

Write-Host "Checking resources without required tags..."
az resource list --resource-group $ResourceGroupName `
  --query "[?tags.owner==null || tags.environment==null].{Name:name, Type:type, Tags:tags}" -o table

Write-Host "Checking Network Security Groups..."
az network nsg list --resource-group $ResourceGroupName --query "[].{Name:name, Location:location}" -o table

Write-Host "Validation completed. Review missing tags, diagnostics and access controls manually before production use."
