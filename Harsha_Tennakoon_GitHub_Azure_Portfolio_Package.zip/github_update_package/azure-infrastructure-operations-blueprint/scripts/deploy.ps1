param(
    [Parameter(Mandatory=$true)] [string] $SubscriptionId,
    [Parameter(Mandatory=$true)] [string] $ResourceGroupName,
    [string] $Location = "swedencentral"
)

Write-Host "Setting subscription context..."
az account set --subscription $SubscriptionId

Write-Host "Creating resource group if missing..."
az group create --name $ResourceGroupName --location $Location | Out-Null

Write-Host "Deploying Bicep template..."
az deployment group create `
  --resource-group $ResourceGroupName `
  --template-file "../bicep/main.bicep" `
  --parameters "../bicep/parameters.dev.json"

Write-Host "Deployment completed. Review outputs and Azure Portal resources."
