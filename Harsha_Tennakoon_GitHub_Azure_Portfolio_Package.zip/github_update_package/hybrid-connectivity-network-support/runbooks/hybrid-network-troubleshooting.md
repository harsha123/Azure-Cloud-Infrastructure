# Hybrid Network Troubleshooting Runbook

## Step 1 — Scope the issue

- Is the problem affecting all users or one site?
- Is the problem cloud-to-on-premises, on-premises-to-cloud or user-to-cloud?
- Did the issue start after a change?

## Step 2 — DNS validation

- Confirm FQDN resolves correctly
- Compare internal and external DNS results
- Check private DNS zone links if private endpoints are used

## Step 3 — Routing validation

- Check effective routes on the Azure NIC
- Check route tables and UDRs
- Confirm BGP advertisements if ExpressRoute/VPN is used

## Step 4 — Security validation

- Review NSG effective rules
- Review Azure Firewall/on-premises firewall logs
- Confirm required ports and protocols

## Step 5 — Connectivity validation

- Test TCP port connectivity
- Test from correct source subnet or jump host
- Use packet capture or Network Watcher where available

## Step 6 — Resolution and documentation

- Apply approved fix
- Validate service recovery
- Update incident ticket and runbook
- Raise problem record for recurring issues
