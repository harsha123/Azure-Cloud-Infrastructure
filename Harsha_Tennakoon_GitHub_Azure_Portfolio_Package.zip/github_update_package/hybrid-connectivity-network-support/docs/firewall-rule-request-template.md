# Firewall Rule Request Template

## Request information

- Requester:
- Application/service:
- Business owner:
- Environment: dev/test/prod
- Change ticket:

## Traffic details

| Field | Value |
|---|---|
| Source IP/subnet |  |
| Destination IP/FQDN |  |
| Port/protocol |  |
| Direction |  |
| Business justification |  |
| Expiry date if temporary |  |

## Validation plan

- DNS test:
- Connectivity test:
- Application test:
- Monitoring confirmation:

## Rollback plan

- Remove rule:
- Restore previous configuration:
- Notify stakeholders:
