# Hybrid Connectivity Design Notes

## Design goals

- Secure connectivity between Azure and on-premises network
- Predictable routing and DNS behavior
- Clear firewall rule ownership
- Supportable operational model
- Monitoring and escalation process

## Common components

- Azure VNet
- VPN Gateway or ExpressRoute Gateway
- On-premises firewall/router
- DNS forwarders or private DNS zones
- Route tables / UDRs
- NSGs
- Network monitoring tools

## Key design questions

1. Which applications require hybrid access?
2. What source and destination networks are involved?
3. Which ports and protocols are needed?
4. Who owns firewall approval?
5. What is the failover path?
6. How will DNS resolution work?
7. What logs are available during troubleshooting?

## Operational notes

- Keep a traffic matrix for each application.
- Use change control for routing/firewall updates.
- Monitor tunnel status, latency and packet loss.
- Document escalation path between cloud, network, security and application teams.
