# ExpressRoute Readiness Checklist

## Business and service requirements

- Critical applications identified
- Bandwidth requirements estimated
- Latency sensitivity reviewed
- Availability target agreed
- RTO/RPO dependency reviewed

## Technical requirements

- Private peering requirement confirmed
- Microsoft peering requirement confirmed, if needed
- IP addressing plan reviewed
- Routing domains documented
- BGP ASN information available
- Firewall rule requirements defined
- DNS resolution model agreed

## Operations readiness

- Monitoring ownership confirmed
- Escalation path documented
- Failover test plan prepared
- Change and rollback plan approved
- Support runbook created
