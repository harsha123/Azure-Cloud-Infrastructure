param(
    [Parameter(Mandatory=$true)] [string] $TargetHost,
    [int] $Port = 443
)

Write-Host "Testing DNS resolution for $TargetHost"
Resolve-DnsName $TargetHost -ErrorAction SilentlyContinue

Write-Host "Testing TCP connectivity to $TargetHost on port $Port"
Test-NetConnection -ComputerName $TargetHost -Port $Port

Write-Host "Tip: For Azure VM network issues, also check effective NSG rules, effective routes and firewall logs."
