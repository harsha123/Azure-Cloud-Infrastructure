# Hybrid Connectivity & Network Support

This repository documents practical hybrid cloud networking concepts for Azure and on-premises environments.

## Focus Areas

- Site-to-site VPN design notes
- ExpressRoute readiness checklist
- DNS, routing and firewall troubleshooting
- NSG and route table validation
- Hybrid incident triage workflow

## Why this matters

Many Azure production issues are not only cloud issues. They often include DNS, routing, firewall, VPN, ExpressRoute, identity and on-premises dependencies. This project demonstrates a structured way to analyze hybrid connectivity problems.

## Repository Structure

```text
.
├── docs/
│   ├── hybrid-connectivity-design.md
│   ├── expressroute-readiness-checklist.md
│   └── firewall-rule-request-template.md
├── runbooks/
│   └── hybrid-network-troubleshooting.md
└── scripts/
    └── test-azure-network-path.ps1
```

## Skills Highlighted

TCP/IP, DNS, DHCP, routing, firewalls, VPN/ExpressRoute concepts, VNet peering, NSGs, route tables, Azure Network Watcher concepts and structured L2/L3 troubleshooting.
