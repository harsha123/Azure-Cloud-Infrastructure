# Azure Monitoring, Backup & Resilience

This repository demonstrates practical monitoring and backup readiness for Azure infrastructure operations.

## Focus Areas

- Azure Monitor and Log Analytics operational checks
- Alerting design for infrastructure support
- Backup policy validation
- Restore readiness checklist
- Incident response and RCA templates

## Repository Structure

```text
.
├── kql/
│   ├── vm-heartbeat.kql
│   ├── failed-signins-summary.kql
│   └── high-cpu-vms.kql
├── scripts/
│   ├── check-backup-status.ps1
│   └── export-vm-inventory.ps1
└── runbooks/
    ├── backup-restore-checklist.md
    ├── monitoring-alert-response.md
    └── root-cause-analysis-template.md
```

## Skills Highlighted

Azure Monitor, Log Analytics, KQL, alert handling, Azure Backup, operational runbooks, incident triage and service restoration.
