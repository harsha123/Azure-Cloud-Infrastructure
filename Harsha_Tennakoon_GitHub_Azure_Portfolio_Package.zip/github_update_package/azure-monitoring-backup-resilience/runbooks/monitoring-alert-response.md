# Monitoring Alert Response Runbook

## 1. Acknowledge alert

- Confirm alert name and severity
- Check affected resource
- Check alert time and frequency

## 2. Validate impact

- Is the resource down or degraded?
- Are users affected?
- Is there a related change or incident?

## 3. Analyze signals

- Metrics
- Logs
- Activity Log
- Resource Health
- Dependency checks

## 4. Take action

- Apply approved recovery step
- Escalate to correct owner if needed
- Communicate status

## 5. Close and improve

- Document root cause or known reason
- Update alert threshold if noisy
- Update runbook if new learning is found
