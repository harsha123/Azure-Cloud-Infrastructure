# Root Cause Analysis Template

## Incident summary

- Incident ID:
- Date/time:
- Service affected:
- Impact:
- Duration:

## Timeline

| Time | Event |
|---|---|
|  |  |

## Root cause

Explain the technical and process cause clearly.

## Resolution

Describe what restored the service.

## Preventive actions

| Action | Owner | Due date | Status |
|---|---|---|---|
|  |  |  |  |

## Lessons learned

- What worked well?
- What should be improved?
- What monitoring/runbook changes are needed?
