# Backup and Restore Checklist

## Backup validation

- Confirm backup policy is assigned
- Confirm last successful backup time
- Check failed backup jobs
- Check retention settings
- Confirm backup alerts are configured

## Restore readiness

- Identify restore point
- Confirm restore target resource group/VNet
- Validate access permissions
- Confirm downtime window if production
- Document validation steps after restore

## Restore test evidence

- Restore test date:
- Restored resource:
- Test result:
- Issues found:
- Corrective actions:
