param(
    [Parameter(Mandatory=$true)] [string] $ResourceGroupName,
    [Parameter(Mandatory=$true)] [string] $VaultName
)

Write-Host "Checking Azure Recovery Services Vault backup jobs..."

az backup job list `
  --resource-group $ResourceGroupName `
  --vault-name $VaultName `
  --query "[].{Operation:operation, Status:status, Start:startTime, End:endTime, Entity:entityFriendlyName}" `
  -o table

Write-Host "Review failed or long-running jobs and confirm last successful backup for critical VMs."
