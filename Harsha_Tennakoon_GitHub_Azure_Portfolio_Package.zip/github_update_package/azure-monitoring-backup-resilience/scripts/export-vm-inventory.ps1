param(
    [string] $OutputPath = "vm-inventory.csv"
)

Write-Host "Exporting Azure VM inventory..."

$vms = az vm list -d --query "[].{Name:name, ResourceGroup:resourceGroup, Location:location, PowerState:powerState, Size:hardwareProfile.vmSize, PrivateIP:privateIps, PublicIP:publicIps}" -o json | ConvertFrom-Json
$vms | Export-Csv -Path $OutputPath -NoTypeInformation

Write-Host "VM inventory exported to $OutputPath"
