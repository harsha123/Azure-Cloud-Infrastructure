# CV Folder

This folder contains the latest Azure Cloud Infrastructure Engineer CV. Before uploading it to a public GitHub repository, remove private information such as phone number, personal address, passport/visa details, and any sensitive references.
